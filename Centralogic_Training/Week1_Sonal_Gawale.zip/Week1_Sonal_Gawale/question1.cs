﻿
        String name = Console.ReadLine();
        Console.WriteLine("Hello "+name+"!");
   

﻿internal class Program
{
    private static void Main(string[] args)
    {
        // Variable Declaration
        String favColor;

        //Store value of favourite color
        favColor = "Violet";

        Console.WriteLine("My Favourite Colour is "+favColor);
    }
}
